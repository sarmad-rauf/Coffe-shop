module.exports = {

    MongoURI:'mongodb+srv://sarmad:agentrosepetal1122@cluster0-ouryk.mongodb.net/test?retryWrites=true&w=majority'
}